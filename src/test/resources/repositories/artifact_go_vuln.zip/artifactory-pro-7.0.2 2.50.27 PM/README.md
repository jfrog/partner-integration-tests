### System Requirements
Before you install, please validate the system requirements provided here: https://www.jfrog.com/confluence/display/JFROG/System+Requirements  
​
### How to run
* `./config.sh` # should provide you an interactive install or upgrade
​
### Default credentials for PostgreSQL
username: artifactory
password: password

### MORE DETAILS 
For more details on installation scripts, refer: https://www.jfrog.com/confluence/display/JFROG/Installing+Artifactory

For more details on  Upgrade scripts, refer: https://www.jfrog.com/confluence/display/JFROG/Upgrading+Artifactory

For troubleshooting, refer: https://www.jfrog.com/confluence/display/JFROG/Troubleshooting